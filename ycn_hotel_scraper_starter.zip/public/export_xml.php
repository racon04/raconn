<?php
$cacheFile = __DIR__ . '/../storage/cache/hotels.json';
$xmlFile = __DIR__ . '/../storage/xml/hotels.xml';
if (!file_exists($cacheFile)) exit('Önce veri çek.');
$data = json_decode(file_get_contents($cacheFile), true);
$items = $data['items'] ?? [];
if (!$items) exit('Kayıt bulunamadı.');
$xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><hotels></hotels>');
foreach ($items as $i => $hotel) {
    $node = $xml->addChild('hotel'); $node->addAttribute('id', (string)($i+1));
    $node->addChild('city', htmlspecialchars($hotel['city'] ?? ''));
    $node->addChild('district', htmlspecialchars($hotel['district'] ?? ''));
    $node->addChild('title', htmlspecialchars($hotel['title'] ?? ''));
    $node->addChild('slug', htmlspecialchars($hotel['slug'] ?? ''));
    $node->addChild('address', htmlspecialchars($hotel['address'] ?? ''));
    $node->addChild('description', htmlspecialchars($hotel['description'] ?? ''));
    $node->addChild('maps_url', htmlspecialchars($hotel['maps_url'] ?? ''));
    $images = $node->addChild('images');
    foreach (($hotel['images'] ?? []) as $img) { $images->addChild('image', htmlspecialchars($img)); }
}
$xml->asXML($xmlFile);
header('Content-Type: application/xml; charset=UTF-8');
header('Content-Disposition: attachment; filename="hotels.xml"');
header('Content-Length: ' . filesize($xmlFile));
readfile($xmlFile); exit;

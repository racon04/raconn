#!/usr/bin/env python3
import argparse, json, re, sys, time
from pathlib import Path
try:
    from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
except Exception:
    print('Playwright kurulu değil. Kurulum: pip install playwright && python3 -m playwright install chromium', file=sys.stderr)
    sys.exit(1)

BASE_DIR = Path(__file__).resolve().parent.parent
CACHE_FILE = BASE_DIR / 'storage' / 'cache' / 'hotels.json'
CITY_QUERIES = {'antalya':'Antalya oteller','alanya':'Alanya oteller','mersin':'Mersin oteller'}
CITY_META = {'antalya':{'city':'Antalya','district':'Merkez'},'alanya':{'city':'Antalya','district':'Alanya'},'mersin':{'city':'Mersin','district':'Merkez'}}

def slugify(value):
    tr = str.maketrans('çğıöşüÇĞİÖŞÜ', 'cgiosuCGIOSU')
    value = value.lower().translate(tr).strip()
    value = re.sub(r'[^a-z0-9]+', '-', value)
    value = re.sub(r'-+', '-', value).strip('-')
    return value or 'otel'

def normalize_img(src):
    src = src or ''
    src = re.sub(r'=w\d+-h\d+(-k-no)?', '=w1600-h900-k-no', src)
    src = re.sub(r'=s\d+(-k-no)?', '=w1600-h900-k-no', src)
    return src

def collect_images(page, max_count=5):
    urls = []
    for img in page.query_selector_all('img'):
        src = normalize_img(img.get_attribute('src') or '')
        if not src: continue
        if not re.search(r'(googleusercontent|gstatic|ggpht)', src, re.I): continue
        if 'maps.gstatic.com/mapfiles' in src: continue
        if src not in urls: urls.append(src)
        if len(urls) >= max_count: break
    return urls

def text_from_selectors(page, selectors):
    for selector in selectors:
        try:
            el = page.query_selector(selector)
            if el:
                txt = (el.inner_text() or '').strip()
                if txt: return txt
        except Exception:
            pass
    return ''

def extract_detail(page, url, city_key):
    page.goto(url, wait_until='domcontentloaded', timeout=60000)
    page.wait_for_timeout(2000)
    title = text_from_selectors(page, ['h1', '.DUwDvf', '.fontHeadlineLarge'])
    if not title: return None
    page_text = page.locator('body').inner_text(timeout=30000)
    lines = [x.strip() for x in page_text.splitlines() if x.strip()]
    address = ''
    for line in lines:
        if re.search(r'(mah\.|mahallesi|sokak|sk\.|cad\.|cd\.|bulvar|blv\.|no:|alanya|antalya|mersin|yenisehir|mezitli|erdemli|konyaalti|muratpasa|kepez)', line, re.I):
            address = line; break
    texts = []
    for sel in ['[aria-label*="Hakkında"]','[aria-label*="About"]','.PYvSYb','.WeS02d','.HlvSq','.fontBodyMedium']:
        for node in page.query_selector_all(sel):
            try: txt = (node.inner_text() or '').strip()
            except Exception: txt = ''
            if not txt or len(txt) < 40: continue
            if re.search(r'(yorum|reviews?|yol tarifi|website|telefon|paylaş|save|yakında|kapalı|açık şimdi)', txt, re.I): continue
            if txt not in texts: texts.append(txt)
    description = sorted(texts, key=len, reverse=True)[0] if texts else ''
    return {'city':CITY_META[city_key]['city'],'district':CITY_META[city_key]['district'],'title':title,'slug':slugify(title),'address':address,'description':description,'images':collect_images(page,5),'maps_url':page.url}

def collect_place_links(page, city_key, limit):
    search_url = 'https://www.google.com/maps/search/' + CITY_QUERIES[city_key].replace(' ', '+')
    page.goto(search_url, wait_until='domcontentloaded', timeout=60000)
    page.wait_for_timeout(4000)
    try:
        page.locator('button:has-text("Tümünü reddet")').click(timeout=3000); page.wait_for_timeout(1000)
    except Exception:
        pass
    feed = None
    for selector in ['div[role="feed"]', '.m6QErb[aria-label]']:
        try:
            feed = page.query_selector(selector)
            if feed: break
        except Exception:
            pass
    if not feed: return []
    last_height = 0; same = 0
    for _ in range(70):
        try: page.evaluate('(el) => el.scrollTo(0, el.scrollHeight)', feed)
        except Exception: pass
        page.wait_for_timeout(1200)
        try: current_height = page.evaluate('(el) => el.scrollHeight', feed)
        except Exception: current_height = 0
        same = same + 1 if current_height == last_height else 0
        last_height = current_height
        if same >= 5: break
    urls = []
    for a in page.query_selector_all('a[href*="/maps/place/"]'):
        href = a.get_attribute('href') or ''
        if href and href not in urls: urls.append(href)
        if len(urls) >= limit: break
    return urls

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--city', required=True, choices=['antalya','alanya','mersin'])
    ap.add_argument('--limit', type=int, default=30)
    args = ap.parse_args()
    results = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=['--disable-blink-features=AutomationControlled'])
        context = browser.new_context(locale='tr-TR', user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', viewport={'width': 1440, 'height': 900})
        page = context.new_page()
        urls = collect_place_links(page, args.city, args.limit)
        seen = set()
        for url in urls:
            try:
                item = extract_detail(page, url, args.city)
                if item and item['slug'] not in seen:
                    seen.add(item['slug']); results.append(item)
            except PlaywrightTimeoutError:
                continue
            except Exception:
                continue
        browser.close()
    payload = {'last_run': time.strftime('%Y-%m-%d %H:%M:%S'),'city': args.city,'count': len(results),'items': results}
    CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Tamamlandı. Kayıt sayısı: {len(results)}')

if __name__ == '__main__':
    main()

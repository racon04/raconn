<?php
$cacheFile = __DIR__ . '/../storage/cache/hotels.json';
$data = ['last_run'=>null,'city'=>null,'count'=>0,'items'=>[]];
if (file_exists($cacheFile)) {
    $decoded = json_decode(file_get_contents($cacheFile), true);
    if (is_array($decoded)) $data = array_merge($data, $decoded);
}
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>YCN Hotel Scraper Panel</title>
<style>
*{box-sizing:border-box}body{margin:0;padding:24px;background:#f5f7fb;color:#1f2937;font-family:Arial,sans-serif}
.wrap{max-width:1280px;margin:0 auto}.card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:20px;box-shadow:0 10px 24px rgba(0,0,0,.06);margin-bottom:18px}
h1{margin:0 0 8px;font-size:32px}.muted{color:#6b7280}.row{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:16px}
select,input,button,a.btn{padding:12px 14px;border:1px solid #d1d5db;border-radius:12px;background:#fff;font-size:14px}
button,a.btn.primary{background:#2563eb;color:#fff;border:none;cursor:pointer;text-decoration:none}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-top:18px}
.box{padding:16px;border:1px solid #e5e7eb;border-radius:14px;background:#f9fafb}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}
.hotel{background:#fff;border:1px solid #e5e7eb;border-radius:16px;overflow:hidden;box-shadow:0 8px 20px rgba(0,0,0,.05)}.gallery{display:grid;grid-template-columns:repeat(2,1fr);gap:2px;background:#e5e7eb;min-height:180px}
.gallery img{width:100%;height:180px;object-fit:cover;background:#eef2f7}.hotel-body{padding:14px}.hotel h3{margin:0 0 8px;font-size:18px}.rowline{font-size:13px;color:#374151;margin:6px 0}
.desc{margin-top:10px;padding:10px;border-radius:12px;background:#f8fafc;border:1px solid #e5e7eb;font-size:13px;line-height:1.6;color:#374151}.links a{color:#2563eb;text-decoration:none;word-break:break-all}
.empty{padding:28px;text-align:center;color:#6b7280}
</style></head><body><div class="wrap"><div class="card">
<h1>YCN Hotel Scraper Panel</h1><div class="muted">Gerçek verileri çek, panelde kontrol et, sonra XML dışa aktar.</div>
<form class="row" method="post" action="run_scrape.php">
<select name="city" required>
<option value="antalya" <?= $data['city']==='antalya' ? 'selected' : '' ?>>Antalya</option>
<option value="alanya" <?= $data['city']==='alanya' ? 'selected' : '' ?>>Alanya</option>
<option value="mersin" <?= $data['city']==='mersin' ? 'selected' : '' ?>>Mersin</option>
</select>
<input type="number" min="5" max="100" name="limit" value="30" placeholder="Kayıt limiti">
<button type="submit">Otelleri Çek</button>
<?php if (!empty($data['items'])): ?><a href="export_xml.php" class="btn primary">XML Dışa Aktar</a><?php endif; ?>
</form>
<div class="stats">
<div class="box"><strong>Son Çekim</strong><div class="muted" style="margin-top:8px;"><?= e($data['last_run'] ?: '-') ?></div></div>
<div class="box"><strong>Şehir</strong><div class="muted" style="margin-top:8px;"><?= e($data['city'] ?: '-') ?></div></div>
<div class="box"><strong>Kayıt Sayısı</strong><div class="muted" style="margin-top:8px;"><?= e((string)$data['count']) ?></div></div>
</div></div>
<div class="card"><?php if (empty($data['items'])): ?><div class="empty">Henüz veri çekilmedi. Şehir seçip <strong>Otelleri Çek</strong> butonuna bas.</div><?php else: ?><div class="grid">
<?php foreach ($data['items'] as $item): $photos = array_values(array_filter($item['images'] ?? [])); $photos = array_slice($photos, 0, 4); if (empty($photos)) $photos = ['']; ?>
<div class="hotel"><div class="gallery"><?php foreach ($photos as $photo): ?><?php if ($photo): ?><img src="<?= e($photo) ?>" alt="<?= e($item['title'] ?? '') ?>"><?php else: ?><div></div><?php endif; ?><?php endforeach; ?></div>
<div class="hotel-body"><h3><?= e($item['title'] ?? 'İsimsiz Otel') ?></h3>
<div class="rowline"><strong>Şehir:</strong> <?= e($item['city'] ?? '-') ?></div>
<div class="rowline"><strong>Bölge:</strong> <?= e($item['district'] ?? '-') ?></div>
<div class="rowline"><strong>Adres:</strong> <?= e($item['address'] ?? '-') ?></div>
<div class="rowline links"><strong>Maps:</strong> <?php if (!empty($item['maps_url'])): ?><a href="<?= e($item['maps_url']) ?>" target="_blank">Haritada Aç</a><?php else: ?>-<?php endif; ?></div>
<div class="desc"><strong>Açıklama:</strong><br><?= nl2br(e($item['description'] ?? 'Açıklama bulunamadı.')) ?></div></div></div>
<?php endforeach; ?></div><?php endif; ?></div></div></body></html>

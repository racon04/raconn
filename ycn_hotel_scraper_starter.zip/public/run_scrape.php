<?php
$city = $_POST['city'] ?? 'antalya';
$limit = (int)($_POST['limit'] ?? 30);
$limit = max(5, min(100, $limit));
$allowed = ['antalya', 'alanya', 'mersin'];
if (!in_array($city, $allowed, true)) exit('Geçersiz şehir.');
$python = trim(shell_exec('which python3'));
if (!$python) exit('python3 bulunamadı.');
$script = realpath(__DIR__ . '/../scraper/scrape_hotels.py');
$cacheDir = realpath(__DIR__ . '/../storage/cache');
$cmd = sprintf('%s %s --city %s --limit %d 2>&1', escapeshellarg($python), escapeshellarg($script), escapeshellarg($city), $limit);
$output = shell_exec($cmd);
$cacheFile = $cacheDir . '/hotels.json';
if (!file_exists($cacheFile)) { echo '<pre>' . htmlspecialchars((string)$output, ENT_QUOTES, 'UTF-8') . '</pre>'; exit; }
header('Location: /'); exit;

Kurulum:
apt update && apt install -y python3 python3-pip php php-cli
pip3 install playwright
python3 -m playwright install chromium

Sonra bu klasör içeriğini /home/ycn-hotel-panel içine kopyala.
